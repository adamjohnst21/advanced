# -*- coding: utf-8 -*-
"""
classification_non_parallel.py

Part of the CLOSIP collection

Author: Adam Johnston 
@adamjohnst21
linkedin.com/in/adamjohnstonuk
"""

import gdal
import numpy
import time
import sys
from data_writer import writeGeoTiff

start_time = time.time()

def main():
    """
    main is function for running this classification
    This program is to be run at the command line, accepting 3 arguments:
        1) an output file name as a string. E.g "Classified_image.tif"
        2) The number of classification groups you want. E.g 8
        3) The full/relative file path of an input image as a string. E.g "images/dovestone_b4.tif"
    
    The input image is converted to a numpy array, classification group boundaries 
    are based on histogram boundaries of this data.
    These classified sections are then collated and written to a new geotiff.     
    """
    
    #Set user arguments to variables
    outputFile = sys.argv[1] # output file name
    classNo = int(sys.argv[2]) # Number of classification groups
    fPath = sys.argv[3] # image to classify
    
    try:
        #read geotiff then convert to array
        nRead = gdal.Open(fPath, gdal.GA_ReadOnly)
        nArray = numpy.array(nRead.ReadAsArray())
        
        # get the classification boundaries
        classes = numpy.histogram(nArray, bins=classNo)[1]
        
        # a list to hold the classification group vlaues
        classValues =[]
        
        #add in the classification group values to the list
        for i in range(classNo + 1):
            classValues.append(i)
        
        print('Image uploaded and classes determined')
        
        #Holds the list of classified rows
        imageSection = []
        
        #loop through the image array 
        for i in range(len(nArray)):
            row = []#list to hold pixel values
            for j in range(len(nArray[i])):
                
                #loop through the number of classes
                for k in range(len(classes) - 1):
                    
                    #find the class of the pixel based on boundaries
                    if classes[k] <= nArray[i][j] <= classes[k+1]:
                        
                        row.append(classValues[k+1]) # add class value to row
            imageSection.append(row) # add row to image
        
        print('Classification complete')
        
        #### Adding values into numpy array ####
        #I know this could have been done more efficiently in this file, but this
        #is meant to mimic the classification_parallel.py methods 
        
        #create a empty array with the dimensions of the original image
        classArray = numpy.zeros((nArray.shape[0],nArray.shape[1]))  
        
        #looping through the  new array
        for i in range(len(classArray)):
            for j in range(len(classArray[i])):
                classArray[i][j] = imageSection[i][j] # add in the respective classified pixel value from the list
        
        #Write out the new classified array as a geotiff        
        writeGeoTiff(classArray, nRead, outputFile)
        
        print ('Program successfully run in:')
        print("--- %s seconds ---" % (time.time() - start_time))
    
    #print to console with message if processing can't be complete    
    except:
        print('Please check your inputs/file paths and try again')
    

if __name__ == "__main__":
   main()
