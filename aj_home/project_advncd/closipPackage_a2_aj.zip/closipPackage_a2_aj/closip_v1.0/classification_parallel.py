# -*- coding: utf-8 -*-
"""
classification_parallel.py

Part of the CLOSIP collection

multiprocessing sections in task() and main() are attributed to model.py Version 1.0
    <A href="http:#www.geog.leeds.ac.uk/people/a.evans/">Dr Andy Evans</A>

Author: Adam Johnston 
@adamjohnst21
linkedin.com/in/adamjohnstonuk
"""
# import libraries
import multiprocessing
import sys
import gdal
import numpy
import time
from data_writer import writeGeoTiff

start_time = time.time() #Starts timer 

class imageClassifier :
    """
    imageClassifier is main class for running this classification
    This program is to be run at the command line, accepting 3 arguments:
        1) an output file name as a string. E.g "Classified_image.tif"
        2) The number of classification groups you want. E.g 8
        3) The full/relative file path of an input image as a string. E.g "images/dovestone_b4.tif"
    
    The input image is converted to a numpy array, classification group boundaries 
    are based on histogram boundaries of this data.
    The image is split into roughly equal sections, each available node will classify
    it's respective section based on the histogram.
    These classified sections are then collated and written to a new geotiff.     
    """
    
    #Contains all the processing aprts
    def task(self, node, number_of_nodes, pipes):    
        
        #Assign user arguments to variables
        outputFile = sys.argv[1] # output file name
        classNo = int(sys.argv[2]) # Number of classification groups
        imgPath = sys.argv[3] # image to classify
        
        # So we can print there has been an error if one occurs
        try:
            
            #Open the geotiff images using gdal
            #Any file path errors are picked up here
            imgRead = gdal.Open(imgPath, gdal.GA_ReadOnly)
            imgArray = numpy.array(imgRead.ReadAsArray()) #your image array
    
            #Find the number of rows in the image
            number_of_rows = len(imgArray)
            
            #create an array to hold each specific node's row section
            node_number_of_rows = 0
    
            #Get classification boundaries
            classes = numpy.histogram(imgArray, bins=classNo)[1]
            
            #list to hold the classification group values
            classValues =[]
            
            #fill the list of classification values
            for i in range(classNo + 1):
                classValues.append(i)
    
            pipe_to_zero = None
            
            # give a status update on the console
            print('Image uploaded and classes determined in node: ', node)
    
            # if the current node isn't  the parent node
            if (node != 0):
                
                #list for image section boundaries between nodes
                rowBounds = [0]
                
                # Average number of rows per node 
                node_number_of_rows = int(number_of_rows/(number_of_nodes - 1))
                
                #add the boundary of each consecutive section. Excluding parent
                # and last node
                for i in range(number_of_nodes - 2):
                    rowBounds.append(rowBounds[i] + node_number_of_rows)
                
                # This adds in the boundary of the last node
                rowBounds.append(rowBounds[-1] + int(node_number_of_rows + (number_of_rows % (number_of_nodes - 1))))

                pipe_to_zero = pipes[node - 1]
                
                #list to hold the classified rows for that nodes image section
                imageStrip = []
                
                #loop through the number of nodes
                for i in range(number_of_nodes):
                    
                    # This is how we make sure different nodes process different
                    #sections of the image. 
                    if (node - 1) == i:
                        
                        #loop through the rows in that nodes section
                        for j in range(rowBounds[i], rowBounds[i+1]): #use the boundaries as the range to loop through
                            
                            #list of pixels per row
                            row = []
                            
                            #loop through the pixels in that row
                            for k in range(len(imgArray[j])):
                                
                                #loop through the classication values list
                                for m in range(len(classes) - 1):
                                    
                                    #find the class the pixel value belongs to
                                    if classes[m] <= imgArray[j][k] <= classes[m+1]:
                    
                                        row.append(classValues[m+1]) #add the value to the row
                            #add the classified row to the image strip list            
                            imageStrip.append(row)
                            
                # console update            
                print('node', node, 'had finished classifying its section')
                                
                                    
                #send the image section to the parent node                 
                pipe_to_zero.send(imageStrip)
    
            
     
            else : # if node is node zero
                
                #list to add image sections into
                image = [] 
    
                # loop through each child node pipe            
                for i in range (len(pipes)):
     
                    # get the image section sent
                    imageStrip = pipes[i].recv() 
                    
                    #loop through that list
                    for j in range(len(imageStrip)):
                        
                        #add each row to the main image list
                        image.append(imageStrip[j])
               
                #console update
                print('Node 0 has stitched together each section')
                
                #Create an empty array with the dimensions of the original image
                classArray = numpy.zeros((imgArray.shape[0],imgArray.shape[1]))  
                
                #loop through each pixel of the anew array
                for i in range(len(classArray)):
                    for j in range(len(classArray[i])):
                        
                        #change the value in the array to list value
                        classArray[i][j] = image[i][j]
                
                # write the classified array to a geotiff
                writeGeoTiff(classArray, imgRead, outputFile)
                print("--- %s seconds ---" % (time.time() - start_time))


                    
 
        # if the processing didn't work
        except:
            print('Please check your inputs/file paths and try again')
    

    
    
    def main(self):
        '''
         This sets up the parellisation bits, assessing the number of nodes,
         setting up the parent/child nodes and connections.
         It then begins the processing, task(), on each node
        '''
        
        #initialise some variables
        number_of_nodes = multiprocessing.cpu_count() # returns number of cpus on computer
        processes = []
        parent_pipes = []
        child_pipes = []
        
        print('This computer has', number_of_nodes, 'CPUs for processing')
        
        # Make the communication pipes.
        for i in range(1, number_of_nodes):
            parent_conn, child_conn = multiprocessing.Pipe()
            parent_pipes.append(parent_conn)
            child_pipes.append(child_conn)
 
        # Give node zero one end of the pipes and start it processing.
        p0 = multiprocessing.Process(group=None, target=self.task, name=None, args=(0, number_of_nodes, parent_pipes), kwargs={})#, daemon=None)
        processes.append(p0)
        p0.start()
 
        # Give the other nodes the other ends, and start them processing.
        for i in range(1, number_of_nodes):
            p = multiprocessing.Process(group=None, target=self.task, name=None, args=(i, number_of_nodes, child_pipes), kwargs={})#, daemon=None)
            processes.append(p)
            p.start()   
            
        # Wait for all processes to finish before exiting. 
         
        for p in processes:
            p.join()
            
     
        
if __name__ == "__main__":

    imageClassifier().main()