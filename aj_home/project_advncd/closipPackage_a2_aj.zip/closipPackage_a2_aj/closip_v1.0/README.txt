CLOSIP Package V 1.0

The Command Line Optical Satellite Image Processor package is a project developed as the final 
deliverable for Advanced Programming, MSc GIS at the University of Leeds. CLOSIP has a selection
of tools for analysing and processing optical imagery, for which it is important to process several
spectral band images together.
The main aim of the project was to develop my image processing skills with parallel processing
optimisation. 


#################### Requirements ####################

Run in python 3 environment

Libraries used:
	gdal
	numpy
	time
	copy
	sys 
	multiprocessing
	sklearn
	

#################### Tools ####################

NDVI calculator (ndvi.py)
	
	"""
	input nir and vr spectral bands geotiff images.
	calculates ndvi
	returns Normalised Difference Vegetation Index (NDVI) as .tif
	"""
	
	arg[1] : The full/relative file path of a nir band image as a string. E.g "images/dovestone_b8.tif"
	arg[2] : The full/relative file path of a vr band  image as a string. E.g "images/dovestone_b4.tif"
	arg[3] : (optional) an output file name as a string. E.g "NDVI_image.tif"
	
	example command line command: >python ndvi.py "images/dovestone_b8.tif" "images/dovestone_b4.tif" "NDVI_test.tif"

	
k-means classifier (classification_kMeans.py)
	
	"""
	input between 2-3 spectral band geotiff images and number of classes
	Runs k-means classification
	returns unsupervised classification as .tif
	"""
	
	arg[1] : an output file name as a string. E.g "Classified_image.tif"
	arg[2] : The number of classification groups you want. E.g 8
	arg[3] : The full/relative file path of the first image as a string. E.g "images/dovestone_b2.tif"
	arg[4] : The full/relative file path of a second image as a string. E.g "images/dovestone_b3.tif"
	arg[5] : (optional) The full/relative file path of a third image as a string. E.g "images/dovestone_b8.tif"
	
	example command line command: >python kMeansClassification.py "kMean_b4_b8.tif" 8 "images/dovestone_b4.tif" "images/dovestone_b8.tif"
	
	
non-parallel classifier (classification_non_parallel.py)
	
	"""
	input a one band geotiff image
	runs histogram classification 
	returns unsupervised classification as .tif
	"""
	
	arg[1] : an output file name as a string. E.g "Classified_image.tif"
	arg[2] : The number of classification groups you want. E.g 8
	arg[3] : The full/relative file path of an input image as a string. E.g "images/dovestone_b4.tif"
	
	example command line command: >python classification_non_parallel.py "np_class.tif" 8 "NDVI.tif"
	

parallel classifier (classification_parallel.py)
	
	"""
	input a one band geotiff image
	runs histogram classification using parallel processing
	returns unsupervised classification as .tif
	"""
	
	arg[1] : an output file name as a string. E.g "Classified_image.tif"
	arg[2] : The number of classification groups you want. E.g 8
	arg[3] : The full/relative file path of an input image as a string. E.g "images/dovestone_b4.tif"
	
	example command line command: >python classification_parallel.py "p_class.tif" 8 "NDVI.tif"
	
	
	
#################### Version 1.0 ####################

Release (2018/05/21)

Updates:
	N/A
	
	
#################### Author ####################

Written by Adam Johnston

GitHub: adamjohnst21.github.io/advanced/aj_home
twitter: @adamjohnst21
linkedin: in/adamjohnstonuk


#################### License ####################

GNU GENERAL PUBLIC LICENSE
Version 3, 29 June 2007

Copyright (C) 2007 Free Software Foundation, Inc. <http://fsf.org/>
Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.