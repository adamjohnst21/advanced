# -*- coding: utf-8 -*-
"""
data_writer.py

Part of the CLOSIP collection

While this is standard code for creating a geotiff, it has been previously 
used by Adam Johnston in a past 'Radar waterbodies' project, and adapted
into a function.

Author: Adam Johnston 
@adamjohnst21
linkedin.com/in/adamjohnstonuk
"""
import gdal

def writeGeoTiff(array, projFile, outfile):
      """
        writeGeoTiff() writes geotiff images from numpo arrays
        It requires 3 arguments:
            1) a 2 dimensional numpy array. E.g. [[2, 4, 7...], [...]]
            2) a gdal read of a geotiff file, providing projection information
            3) an output file name in string format. E.g. "ndvi.tif"
      """ 
      
       #Get the dimensions of the image based on array  
      [cols,rows] = array.shape
      
      #Use the projcetion info from the input image
      trans       = projFile.GetGeoTransform()
      proj        = projFile.GetProjection()
      
      #set no data to 0
      nodatav     = 0
       
      # creates new tif based on spec of original image
      outdriver = gdal.GetDriverByName("GTiff")
      outdata   = outdriver.Create(str(outfile), rows, cols, 1, gdal.GDT_Float32)
      
      # specify array to write file from
      outdata.GetRasterBand(1).WriteArray(array)
       
      # set no data val to 0
      outdata.GetRasterBand(1).SetNoDataValue(nodatav)
       
      # set geogeom to that of original image
      outdata.SetGeoTransform(trans)
       
      # set projection info to same as original image (WGS-84)
      outdata.SetProjection(proj)