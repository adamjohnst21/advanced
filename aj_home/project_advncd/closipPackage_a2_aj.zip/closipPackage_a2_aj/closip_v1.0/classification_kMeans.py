# -*- coding: utf-8 -*-
"""
classification_kMeans.py

Part of the CLOSIP collection

Author: Adam Johnston 
@adamjohnst21
linkedin.com/in/adamjohnstonuk

"""
#import libraries needed
import gdal
import numpy
import copy
import sys
from data_writer import writeGeoTiff
from sklearn import cluster

def main():
    """
    main() is main function for running this classification
    This program is to be run at the command line, accepting 4-5 arguments:
        1) an output file name as a string. E.g "Classified_image.tif"
        2) The number of classification groups you want. E.g 8
        3) The full/relative file path of the first image as a string. E.g "images/dovestone_b2.tif"
        4) The full/relative file path of a second image as a string. E.g "images/dovestone_b3.tif"
        5) (optional) The full/relative file path of a third image as a string. E.g "images/dovestone_b8.tif"
    
    The input images are converted to a numpy array.
    The bands are then collated, so same pixel values are in a list
    The k-means classification is then run, based on these 2-3 axis
    Classified list is t back into an image framework and converted to a geotiff
    """
    
    #Used to change between 2 or 3 image bands
    thirdBand = True
    
    #Assign the output filename and number of classes entered
    outputName = sys.argv[1]
    numberOfClasses = int(sys.argv[2])
    
    #Get entered filepath names for 2 image bands
    fPath = sys.argv[3]
    f2Path = sys.argv[4]

    
    #This is used to test for a third entered band
    try:
        f3Path = sys.argv[5]
        n3Read = gdal.Open(f3Path, gdal.GA_ReadOnly)
        n3Array = numpy.array(n3Read.ReadAsArray())
    except: 
        #if the third band wasn't there, or isn't correct
        #change the variable to false, this decides a later branch of code
        thirdBand = False
        print('--> No third band entered or recognised')
        
    
    try: 
        
        #open the images with gdal, then convert to a numpy array
        nRead = gdal.Open(fPath, gdal.GA_ReadOnly) #open the image
        nArray = numpy.array(nRead.ReadAsArray()) #convert to an array
        n2Read = gdal.Open(f2Path, gdal.GA_ReadOnly)
        n2Array = numpy.array(n2Read.ReadAsArray())
        
        #image bands are collated into a 2-dimenional array. KMeans()
        #doesn't accept 3-D arrays, so we remove the rows later on
        joinedArray = []
        
        #Create a copy of the array for the classified image
        classCopy =copy.copy(nArray)
        
        #If a third band was accepted
        if (thirdBand):
            
            #loop through each pixel
            for i in range(len(nArray)):
                for j in range(len(nArray[i])):
                    
                    #create list to hold pixel values
                    pixel = []
                    
                    #add the pixel value of each band to the list
                    pixel.append(nArray[i][j])
                    pixel.append(n2Array[i][j])
                    pixel.append(n3Array[i][j])
                    
                    #add the pixel to the main list
                    joinedArray.append(pixel)
                    
        #If a third band wasn't accepted (false)            
        else:
            
            #Same as above with no third band 
            for i in range(len(nArray)):
                for j in range(len(nArray[i])):
                    pixel = []
                    pixel.append(nArray[i][j])
                    pixel.append(n2Array[i][j])
                    joinedArray.append(pixel)
            
        print('--> Bands read and joined')
        print('--> Running cluster analysis...')  
        
        # Set up the k-means analysis, setting the number of classes
        k_means = cluster.KMeans(n_clusters=numberOfClasses)
        
        # Run the k-means analysis on the array of pixel value lists
        k_means.fit(joinedArray)
        
        print('--> K-Means cluster analysis complete')
          
        # used to iterate through classification results
        m = 0
        
        #Convert classification results from current list of pixels into a 2-d
        #array, image framework with rows and columns
        #lop through the pixels of the array copy
        for i in range(len(classCopy)):
            for j in range(len(classCopy[i])):
                
                #assign the array value the value of classification list
                classCopy[i][j] = k_means.labels_[m] + 1 # + 1 means first value is 1, not 0
                
                m += 1 #next pixel in the k-means results
         
        #Write the array to a geotiff, using reference from input image and 
        #user defined output name
        writeGeoTiff(classCopy, nRead, outputName)
        
        print('--> Classification image successfully written')
    
    #If there was an issue, likely from user input
    except:
        print('--> Please check your inputs and file paths are correct and try again')
        
if __name__ == "__main__":
   main()