# -*- coding: utf-8 -*-
"""
ndvi.py

Part of the CLOSIP collection

Author: Adam Johnston 
@adamjohnst21
linkedin.com/in/adamjohnstonuk
"""

#Import libraries
import sys
import gdal
import numpy
import copy
from data_writer import writeGeoTiff


def main():
    """
    main is main function for running this NDVI calculator
    This program is to be run at the command line, accepting 3 arguments:
        1) The full/relative file path of a nir band image as a string. E.g "images/dovestone_b8.tif"
        2) The full/relative file path of a vr band  image as a string. E.g "images/dovestone_b4.tif"
        3) (optional) an output file name as a string. E.g "NDVI_image.tif"
    
    The input images are converted to a numpy array
    Using the (nir-vr)/(nir+vr) formula, the NDVI value is calculated 
    This is then written to a geotiff 
    """
    
    #Get the arguments passed in from the command prompt
    #assign them to variables
    nirPath = sys.argv[1]
    vrPath = sys.argv[2]
    
    #set the output file name
    try:
        outputName = sys.argv[3] #if a name was given in the command prompt
    except:
        outputName = "NDVI.tif" #set a default in case no name argument given
        
    # This is to catch any file path errors given as arg1 and arg2
    try:
        
       #Open the geotiff images using gdal
       nRead = gdal.Open(nirPath, gdal.GA_ReadOnly)
       vRead = gdal.Open(vrPath, gdal.GA_ReadOnly)
        
        
        #create a numpy array from this read
       nirArray = numpy.array(nRead.ReadAsArray())
       vrArray = numpy.array(vRead.ReadAsArray())
       
       print('NIR and VR bands read in successfully')
       
       #create a copy of the image array to put NDVI results in 
       ndviArray = copy.copy(nirArray)
    
        # Go through each row of the image 
       for i in range(len(nirArray)): 
        
           #go through each pixel of the row
           for j in range(len(nirArray[i])):
                
               nir = nirArray[i][j] #get the nir value
               vr = vrArray[i][j] #get the vr value
                
               #Calculate NDVI value, mulitply by 1000 so it will go 
               #in a numpy array
               ndvi = ((nir - vr)/(nir + vr)) * 1000
        
               #This removes any erroneous pixels (see issue 2 in report)
               if ndvi < 1000:
                   ndviArray[i][j] = ndvi #put ndvi value into array copy
                
               else:
                   ndviArray[i][j] = 1 #Assign a value of 1 to error pixel
                   
       print('NDVI calculated')           
                    
       # Write the ndvi array to a geotiff         
       writeGeoTiff(ndviArray, nRead, outputName) 
       
       print('ndvi.py successfully executed')
       
       
    except AttributeError:
        print('Please check your file paths and try again')
    
    
if __name__ == "__main__":
   main()
