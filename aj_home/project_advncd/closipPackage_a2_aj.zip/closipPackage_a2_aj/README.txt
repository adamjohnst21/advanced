This is the deliverable for Advanced Programming Assignment 2 (MSc GIS University of Leeds)

The project report is CLOSIP_report.pdf

The programming component is found in closip_v1.0; the CLOSIP package.
Please see the internal README for more details, this current README is for the assignment assessor

I have included sample imagery in closip_v1.0/images for you to use in testing the package programs,
if you have any issues, please consult the README file

The programs are run from a command line in the closip_v1.0 directory. I used the anaconda prompt, 
as it has all the relevant libraries.

The output geotiff images can't be read in standard image viewers. Use either a GIS (e.g. ArcGIS) or Remote sensing software.
If you don't have any suitable software, ESA SNAP is available free from http://step.esa.int/main/download/