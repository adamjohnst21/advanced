import arcpy
import pythonaddins

 #add the below in somewhere
 #object = pythonaddins.GPToolDialog(toolboxpath, tool_name) 

class ExplosionButtonClass(object):
    """Implementation for addin_addin.explosionbutton (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
	
        object = pythonaddins.GPToolDialog("C:\Users\University\Dropbox\University\Advanced_programming\practicals\prac1_modelBuilder\models.tbx", "explosionscript2") 
		
		