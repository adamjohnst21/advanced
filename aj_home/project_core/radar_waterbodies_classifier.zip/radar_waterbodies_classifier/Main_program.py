"""
Main program file to run the radar image processing 
includes Start and Results classes
    Start runs the first GUI, allwos the user to select files and then process
    those files
    Results opens a second GUI which shows the results from Start() and allows 
    the user to save output files
    
@author: Adam Johnston"""

#import libraries
from tkinter import Tk, Label, Button, Entry, W, E, Toplevel
import gdal
import numpy
from imgFramework import Satimpro
import time 

# Set up of global variables needed to communicate between Start and Result class
timeTaken = 0
aStats = [0, 0, 0, 0]
wbOutput = []
aaOutput = []
radPath = str()

class Start:
    
    #initialise the GUI window
    def __init__(self, master):
        
        """
        Contains the set up for the first GUI that opens when the program is run
        """
        
        self.master = master
        master.title("Water Bodies identifier")
        
        
        #variables to hold the GUI entered file paths 
        self.radarPath = str()
        self.refPath = str()
        
        # create a set of text (labels) for the GUI
        self.label = Label(master, text='Please select the GeoTiff input files')
        self.break1 = Label(master, text='')
        self.break2 = Label(master, text='')
        self.break3 = Label(master, text='')
        self.radarLabel = Label(master, text='Radar image file path')
        self.refLabel = Label(master, text='Reference image file path')
        
        # assigns cecking entered text with validate function.
        # 1 needed for each text entry
        vcmd0 = master.register(self.validate) 
        vcmd1 = master.register(self.validate1)
        
        # creates the text entry for GUI, validated the entry using validate function
        self.radarEntry = Entry(master, validate="key", validatecommand=(vcmd0, '%P'))
        self.refEntry = Entry(master, validate="key", validatecommand=(vcmd1, '%P'))
        
        #creates the buttons for the GUI. commands (when the button is pressed) are linked to running
        # a certain function. 
        self.radarButton = Button(master, text="upload", command=lambda: self.fileUpload('radarUpload'))
        self.refButton = Button(master, text="upload", command=lambda: self.fileUpload('refUpload'))
        self.runButton = Button(master, text="Run Program", command=lambda: self.executeProgram())
        self.resultsButton = Button(master, text='See results', command=lambda: self.resultsWindow())
        
        

        #sets out the layout of the GUI for each widget
        self.label.grid(row=0, column=0, columnspan=4, sticky=W)
        self.break1.grid(row=1, column=0, columnspan=4, sticky=W)
        self.radarLabel.grid(row=3, column=0, sticky=W)
        self.radarEntry.grid(row=4, column=0, columnspan=3, sticky=W)
        self.radarButton.grid(row=4, column=3, sticky=W)
        self.break2.grid(row=5, column=0, columnspan=4, sticky=W)
        self.refLabel.grid(row=6, column=0, sticky=W)
        self.refEntry.grid(row=7, column=0, columnspan=3, sticky=W)
        self.refButton.grid(row=7, column=3, sticky=W)
        self.break3.grid(row=8, column=0, columnspan=4, sticky=W)
        self.runButton.grid(row=9, column=0, columnspan=2, sticky=W)
        self.resultsButton.grid(row=9, column=4, columnspan=2, sticky=E)
        
        

    def validate(self, new_text):
        """
        Checks the entry into the textbox is a string variable
        For the Radar image file path
        """
        
        # if nothing has been entered
        if not new_text: 
            self.radarPath = str()
            return True
        
        #if what has been entered is a string
        try:
            self.radarPath = str(new_text)
            return True
        
        except ValueError: #if it isn't a string
            return False   
     
    def validate1(self, new_text):
        """
        Checks the entry into the textbox is a string variable
        For the Reference image file path
        """
        
        if not new_text:
            self.refPath = str()
            return True

        try:
            self.refPath = str(new_text)
            return True
        except ValueError:
            return False
            
    
    def fileUpload(self, method):
        """
        This doesn't actual hold variables once uploaded, but it checks that what
        has been entered is a valid file path to a .tif file
        """
        #specifies which button has been pressed
        if method == 'radarUpload':
            
            #try to opn file as an array
            try:
                dPath = self.radarPath
                d = gdal.Open(dPath, gdal.GA_ReadOnly) #either this...
                dRay = numpy.array(d.ReadAsArray()) #or this won't work if file path isn't right
                print ('Radar image upload was successful!')
                
            #if it doesn't work, then the entry won't work in the processor
            except:
            
                print ('Radar upload unsuccessful')
                # I would like to include below, but it sems to break the python console
                #print ('Ensure file path is correct. E.g C:\...\file.tif') 
                
        elif method == 'refUpload':
            
            try:
                rPath = self.refPath
                ref = gdal.Open(rPath, gdal.GA_ReadOnly)
                rRay = numpy.array(ref.ReadAsArray())
                print ('Reference image upload was successful!')
                
            
            except:
            
                print ('Reference upload unsuccessful')
                
    def executeProgram(self):
        """
        This runs the main image processing section 
        
        """
        
        #set scope for the variables used to send info to Result class
        global wbOutput
        global radPath
        global aaOutput
        global timeTaken
        
        startTime = time.time() # starts timer for running processing
        
        #store the radar image path in the global variable 
        radPath = self.radarPath
        
        # open the two tif images using gdal, with read only to stop interfering with original
        d = gdal.Open(self.radarPath, gdal.GA_ReadOnly)
        ref = gdal.Open(self.refPath, gdal.GA_ReadOnly)
        
        # create an array of the radar image
        aRay = numpy.array(d.ReadAsArray())
        
        #enter the array into smooth function, r will be the smoothed array
        r = Satimpro.smooth(aRay)
        
        #assign the smoothed array values a likelihood of being water
        Satimpro.assign(r)
        
        #enter the asigned array into the classification, p will be classified array
        p = Satimpro.classify(r)
        
        #store the classified array in the global variable 
        wbOutput = p
        
        #run the accuracy assessment using the classified array. file referenced (d, ref)
        ##needed to create coordinates matrix. aa will be accuracy array
        aa = Satimpro.accuracy(p, d, ref)
        
        #loop through each cell in the aa array
        for i in range(len(aa)):
            for j in range(len(aa[i])):
                global aStats
                
                #we want to know the number of each accuracy score, so each time 
                ## the score ==score, add 1 to that index of list of scores
                if aa[i][j] ==0:
                    aStats[0] += 1
                if aa[i][j] == 3:
                    aStats[3] += 1
                if aa[i][j] ==2:
                    aStats[2] += 1
                if aa[i][j] ==1:
                    aStats[1] += 1
                
        #store the acuracy assessment array in the global variable 
        aaOutput = aa
        
        #Calculate the time taken to run program and store it in variable 
        timeTaken = (time.time() - startTime)
        
        print ('Processing complete! Click on See results')
        
    
    
    def resultsWindow(self):
        
        self.newWindow = Toplevel(self.master)
        self.AJ_GUI = Results(self.newWindow)
        
class Results:
    """
    contains the set up for a second GUI window to open following command from the first.
    This window will display the results and have command to write the output files
    """
    
    def __init__(self, master):
        """
        Sets up the second GUI window
        """
        self.master = master
        master.title('Results')
        
        # set scope of the variables that contain results from Start that we need
        global timeTaken
        global aStats
        global wbOutput
        global aaOutput
        
        
    
        # define the text we want in the GUI window
        self.label = Label(master, text='Please see results below:')
        self.timeLabel = Label(master, text='The program took '+str(timeTaken)+' seconds to complete')
        self.statsLabel = Label(master, text=str(((aStats[3])*0.000196))+'km2 was correctly identified as water, '+str(((aStats[3])/sum(aStats) * 100))+' of the image') # 0.000196 is the km2 value of sentinel-1 GRD data
        self.stats1Label = Label(master, text='Overall the classification was'+str((((aStats[3])+(aStats[0]))/sum(aStats) * 100))+'% correct')
        self.stats2Label = Label(master, text=str(((aStats[2])/sum(aStats) * 100))+'% of the image was water wrongly classed as land')
        self.stats3Label = Label(master, text=str(((aStats[1])/sum(aStats) * 100))+'% of the image was land wrongly classed as water')
        
        # create the buttons for writing the output files
        self.wbWrite = Button(master, text="Save Water mask", command=lambda: self.write('wb'))
        self.aaWrite = Button(master, text="Save Accuracy Assessment", command=lambda: self.write('aa'))
        
        #set up the layout of widgets in the window
        self.label.grid(row=0, column=0, columnspan=4, sticky=W)
        self.timeLabel.grid(row=1, column=0, columnspan=4, sticky=W)
        self.statsLabel.grid(row=2, column=0, columnspan=4, sticky=W)
        self.stats1Label.grid(row=3, column=0, columnspan=4, sticky=W)
        self.stats2Label.grid(row=4, column=0, columnspan=4, sticky=W)
        self.stats3Label.grid(row=5, column=0, columnspan=4, sticky=W)
        self.wbWrite.grid(row=6, column=0, sticky=E)
        self.aaWrite.grid(row=6, column=1, sticky=W+E)
        
        
        
        
    def write(self, method):
        """
        contains the function to write out the output arrays as a geotiff. They are in separate
        methods for each output file
        """
        
        #Set the path of the original radar fil
        global radPath
        
        #We repeat this as our output will have the same geogeometry as the input tif
        d = gdal.Open(radPath, gdal.GA_ReadOnly)
        
        #writes the waterbody mask output as a tif image
        if method == 'wb':
            
            [cols,rows] = wbOutput.shape
            trans       = d.GetGeoTransform()
            proj        = d.GetProjection()
            nodatav     = 0
            outfile     = 'Waterbodies_image.tif'
            
            
            # creates new tif based on spec of original image
            outdriver = gdal.GetDriverByName("GTiff")
            outdata   = outdriver.Create(str(outfile), rows, cols, 1, gdal.GDT_Float32)
        
            # specify array to write file from
            outdata.GetRasterBand(1).WriteArray(wbOutput)
            
            # set no data val to 0
            outdata.GetRasterBand(1).SetNoDataValue(nodatav)
            
            # set geogeom to that of original image
            outdata.SetGeoTransform(trans)
            
            # set projection info to same as original image (WGS-84)
            outdata.SetProjection(proj)
        
        #writes the acuracy assessment output as a tif image
        if method == 'aa':
            global radpath
            
            d = gdal.Open(radPath, gdal.GA_ReadOnly)
            
            #see above 'wb' method for comments
            [cols,rows] = aaOutput.shape
            trans       = d.GetGeoTransform()
            proj        = d.GetProjection()
            nodatav     = 0
            outfile     = 'Accuracy_Assessment.tif'
            outdriver = gdal.GetDriverByName("GTiff")
            outdata   = outdriver.Create(str(outfile), rows, cols, 1, gdal.GDT_Float32)
            outdata.GetRasterBand(1).WriteArray(aaOutput)
            outdata.GetRasterBand(1).SetNoDataValue(nodatav)
            outdata.SetGeoTransform(trans)
            outdata.SetProjection(proj)
        
        
#This creates the loop for the GUI to remain open, set in this way to allow the second gui 
## window to be open as well
def main():
    root = Tk()
    AJ_GUI = Start(root)
    root.mainloop()
  
if __name__ == '__main__':
    main()    
    
