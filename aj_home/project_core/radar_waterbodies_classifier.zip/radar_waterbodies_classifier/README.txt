Instructions for running the 'Waterbodies identifier'

1) run 'main_program.py' in a python environment
2) enter the full file path to the specific geotiff files
	e.g c:\...\fileName.tif
3) click upload 
4) once the python console has specified upload of each was 
	successful, press run to beging processing
5) When the processing is complete, the python console will
	display 'Processing Complete! Click on See results'
6) Click on 'See results' in the GUI to open the results window
7) to save the output geotiff images, press the respective button

the output geotiff images can be viewed in an image viewer or 
	in a GIS as they are geocoded
	
'Waterbodies_image.tif' contains the extracted waterbody mask where
	0 = Land and 1 = Waterbody
	
'Accuracy_Assessment.tif' contains the comparison results between the 
	Waterbody mask and the reference image
	
	3 = Water body correctly classed as Waterbody	
	2 = Waterbody incorrectly classed as Land
	1 = Land incorrectly as Waterbody
	0 = Land correctly classed as Land

	