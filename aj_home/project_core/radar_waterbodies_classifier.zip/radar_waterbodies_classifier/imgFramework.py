"""
Framework paired with main_program.py 

Contains the class 'Satimpro' (Satellite Image Processor) which contains functions;
- smooth (to reduce speckling)
- assign (Assigns water likelihood)
- classify (determines whether cell is part of waterbody)
- accuracy (assesses accuracy of baterbody mask gainst reference file)

@author: Adam Johnston
"""
import copy
from affine import Affine
import numpy

class Satimpro():
    

     
    def smooth(aRay):
        """
        Smooths to reduce speckling
        
        input is 8-bit radar tif as a numpy  array
        returns the smoothed cell values as an array
        """
        #create a temporary function-internal copy of the array to stop effect
        #of moving window algorithm 
        r = copy.copy(aRay)
        
        #loop through each cell
        for i in range(len(aRay)): 
            for j in range(len(aRay[i])): 
                    
                pos = [-1, 0, 1] # list for neighbouring cell indexes
                nbhdTotal = 0 # holds the total of neighbouring cell values
                nbhdCount = 0 # counts number of neighbouring cells
                
                #loops through neighbouring cells
                for m in pos:
                    for n in pos:
                        
                        # This filters out cells outside the image bounds and the current cell itself
                        if (-1 < (i + m) < (len(aRay) - 1)) and (-1 < (j + n) < (len(aRay[i]) - 1)) and ((m**2 + n**2) != 0): 
                            
                            nbhdTotal += aRay[(i+m)][(j + n)]
                            nbhdCount += 1
                
                # calculate neighbourhood average
                nbhdAvg = nbhdTotal/nbhdCount
                x = aRay[i][j] # Just for short hand in below statements
        
        
                try: 
                    y = x - ((x - nbhdAvg)/2) * (nbhdCount/8) # count divided by 8 to make sure there isn't unfair weighting 
                                                                #for cells on the edge of an image with fewer neighbours
                    
                except (ZeroDivisionError): # if 0 then nbhdAvg = cell value and it doesn't need/can't be smoothed
                    y = x
                
                r[i][j] = y #add this value to the copy of the array 
        
        #once the processing is complete, return the copy of the array with new smoothed values
        return (r) 
  
    
    def assign(r):
        
       """
       Assigns cells their likelihood of being water
       
       input is a smoothed radar image in 8-bit array 
       output is an array with values ranging 0-4, representing the likelihood the cell is water
           0=low likelihood 4=high likelihood
       """
       # don't need a copy of the array here as the new values assigned aren't dependent on neighbouring cells
       
       #loop through each cell
       for i in range(len(r)):
            for j in range(len(r[i])):
                
                #this is first as most cells will be 16<, so saves running through them all
                if (r[i][j] >= 16):
                    r[i][j] = 0
                    
                elif (0 <= r[i][j] <= 3):
                    r[i][j] = 4
                    
                elif (4 <= r[i][j] <= 7):
                    r[i][j] = 3
                    
                elif (8 <= r[i][j] <= 11):
                    r[i][j] = 2
                
                #if not above then (12 <= r[i][j] <= 15)
                else:
                    r[i][j] = 1
                    
                    
                
                    
        
                    
    def classify(r):
        """
        Classifies cells as either water or land
        
        input - array with values ranging from 0-4, representing likelihood of water
        output - array of waterbody mask where 0=land and 1=water
        """
        #create a copy of the array to stop effect of moving window algorithm
        q = copy.copy(r)
        
        #loop through all cells in array
        for i in range(len(r)):
            for j in range(len(r[i])):
                
                pos = [-2, -1, 0, 1, 2] #list of 5x5 neighbourhood cell index 

                largeNbhd = [] #creates a list to store neighbourhood values in 
                
                #loop through the neighbourhood cells 
                for m in pos:
                    for n in pos:
                        #filter out cell indexes that are out of the image boundaries
                        if (-1 < (i + m) < (len(r) - 1)) and (-1 < (j + n) < (len(r[i]) - 1)) and ((m**2 + n**2) != 0):
                            
                            #add the value to the list of neighbourhood cells 
                            largeNbhd.append(r[(i+m)][(j + n)])
                
                lnAvg = (sum(largeNbhd)/len(largeNbhd)) # average of the 5x5 neighbourhood
                nbhdRange = (max(largeNbhd) - min(largeNbhd)) # find the range of values in the neighbourhood
                
                # To improve the efficiency of the below chain of if statements,
                # I have tried to order them based on most - least likely to occur
                # first. So for an image which is mostly land, most cells are 
                # classified by two if statements
                
               #if cell has lower likelihood of water 
                if r[i][j] < 2:
                    
                    #if neighbours are also low, cell is land
                    if lnAvg < 2:
                        q[i][j] = 0 
                    
                    #if the neighbourhood is high 
                    elif lnAvg > 3:
                        q[i][j] = 1
                    
                    # if nbhdAvg likelihood is highish, but there is a large range
                    elif (2 < lnAvg <= 3) and (nbhdRange >= 3):
                        q[i][j] = 0 # copy cell is land
                    
                    #if nbhdAvg likelihood is highish but there is a small range (more unanimous)
                    elif (2 < lnAvg <= 3) and (nbhdRange <= 2):
                        q[i][j] = 1 # copy cell is water
                
                # if the cell has a higher likelihood of being water
                elif r[i][j] >= 2:
                    
                    #reverse of the previous set of if statements
                    
                    if lnAvg >= 2:
                        q[i][j] = 1
                    
                    elif lnAvg < 1:
                        q[i][j] = 0
                    
                    elif (1 <= lnAvg < 2) and (nbhdRange >= 3):
                        q[i][j] = 1
                        
                    elif (1 <= lnAvg < 2) and (nbhdRange <= 2):
         
                        q[i][j] = 0
        
        #return the copy containing classification values
        return(q)
                
                        
    def accuracy(p, d, ref):
        """
        determines accuracy of classification
        input- waterbody mask array (0=land 1=water) and reference file array (1=land 2=water)
        output- array with value range 0-3. 0 correct ident as land, 1 = incorrect ident as water
                2 = incorrect identify as land, 3 = correct identify as water
        """
        
        # This creates a matrix to convert between image and WGS-84 coordinates
        T0 = Affine.from_gdal(*d.GetGeoTransform())
        T1 = T0 * Affine.translation(0.5, 0.5) #This sets the WGS-84 coords to pixel center
        
        # to convert between real coords and image coords
        xy2rc = lambda r, c: (c, r) * T1
        
        
        #repeat for the reference image
        T2 = Affine.from_gdal(*ref.GetGeoTransform())
        T3 = T2 * Affine.translation(0.5, 0.5)       
        Rrc2xy = lambda r, c: (c, r) * ~T3 # ' ~ ' inverts the matrix
        
        # create a new array to store the accuracy assessment results in 
        a = copy.copy(p)
        
        # create an array of the reference image
        f = numpy.array(ref.ReadAsArray())
        
        # loop through waterbody array
        for i in range(len(p)):
            for j in range(len(p[i])):
                
                #get the real coordinates for that cell
                pCoords = xy2rc(i, j)
                
                #index of that location in ref file
                fPos = Rrc2xy(pCoords[1], pCoords[0])
                
                #value of ref file at that location
                fVal = f[int(fPos[1])][int(fPos[0])]
                
                #compare the cell value at each location and assign aa vlaue to array copy
                if (p[i][j] == 0) and (fVal == 1):
                    a[i][j] = 0
                
                elif (p[i][j] == 1) and (fVal == 2):
                    a[i][j] = 3
                
                elif (p[i][j] == 0) and (fVal == 2):
                    a[i][j] = 2
                    
                elif (p[i][j] == 1) and (fVal == 1):
                    a[i][j] = 1
        
        # return the copy of the array wit the aa value
        return(a)
        
        

                            
print ('Satimpro all seems kosher')